﻿Imports Microsoft.VisualBasic

Public Class giocatore

    Private lPizzeMangiate As Integer = 0

    'Conta le pizze mangiate
    ReadOnly Property pizzeMangiate As Integer
        Get
            Return lPizzeMangiate
        End Get
    End Property

    'Giocatore mangia le pizze
    Public Function mangia(ByVal nPizzeMangiate As Integer, ByRef objTavolo As tavoloGioco) As Boolean
        'Verifico che sul tavolo ne siano rimaste abbastanza e che no abbia scelto un numero di pizze già scelto prima
        If nPizzeMangiate <= objTavolo.pizzeRimaste And nPizzeMangiate <> objTavolo.pizzeMangiateUltimoTurno Then
            lPizzeMangiate += nPizzeMangiate
            objTavolo.consumaPizze(nPizzeMangiate)
            Return True
        Else
            Return False
        End If
    End Function

End Class

Public Class tavoloGioco

    'Matrice storia tavolo con due colonne: Pizze mangiate e pizze rimaste sul tavolo
    Dim lHistory(100, 1)

    Private turno As Integer = 0
    Private lPizzeRimaste As Integer = 0

    'Conta le pizze rimaste da mangiare
    Property pizzeRimaste As Integer
        Get
            Return lPizzeRimaste
        End Get
        Set(value As Integer)
            lPizzeRimaste = value
        End Set
    End Property

    Public Sub consumaPizze(ByVal pMangiate As Integer)
        lPizzeRimaste -= pMangiate
        turno += 1
        lHistory(turno, 0) = pMangiate
        lHistory(turno, 1) = lPizzeRimaste
    End Sub

    Public Function pizzeMangiateUltimoTurno() As Integer
        Return lHistory(turno, 0)
    End Function

    Public Function verificaVincita() As String
        'Verifico la vincita in base alle pizze residue sul tavolo e alle pizze mangiate all'utimo turno
        Select Case lPizzeRimaste
            Case 0
                Return prossimoGiocatore()
            Case 1
                If pizzeMangiateUltimoTurno() > 1 Then
                    Return giocatoreUltimoTurno()
                Else
                    Return prossimoGiocatore()
                End If
            Case 2
                Return giocatoreUltimoTurno()
        End Select
        Return False
    End Function

    Private Function giocatoreUltimoTurno() As String
        If turno Mod 2 = 0 Then
            Return "G2"
        Else
            Return "G1"
        End If
    End Function

    Private Function prossimoGiocatore() As String
        If turno Mod 2 = 0 Then
            Return "G1"
        Else
            Return "G2"
        End If
    End Function
End Class