﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbTipoGioco = New System.Windows.Forms.GroupBox()
        Me.rbComp = New System.Windows.Forms.RadioButton()
        Me.rbG2 = New System.Windows.Forms.RadioButton()
        Me.rbG1 = New System.Windows.Forms.RadioButton()
        Me.sbTable = New System.Windows.Forms.ProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.sbG1 = New System.Windows.Forms.ProgressBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.sbG2 = New System.Windows.Forms.ProgressBar()
        Me.clbG1 = New System.Windows.Forms.CheckedListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.clbG2 = New System.Windows.Forms.CheckedListBox()
        Me.lbHistory = New System.Windows.Forms.ListBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.udPizze = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbTable = New System.Windows.Forms.Label()
        Me.lblWinner = New System.Windows.Forms.Label()
        Me.lblPizzeG1 = New System.Windows.Forms.Label()
        Me.lblPizzeG2 = New System.Windows.Forms.Label()
        Me.btnStartStop = New System.Windows.Forms.Button()
        Me.gbTipoGioco.SuspendLayout()
        CType(Me.udPizze, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gbTipoGioco
        '
        Me.gbTipoGioco.Controls.Add(Me.rbComp)
        Me.gbTipoGioco.Controls.Add(Me.rbG2)
        Me.gbTipoGioco.Controls.Add(Me.rbG1)
        Me.gbTipoGioco.Location = New System.Drawing.Point(12, 12)
        Me.gbTipoGioco.Name = "gbTipoGioco"
        Me.gbTipoGioco.Size = New System.Drawing.Size(386, 62)
        Me.gbTipoGioco.TabIndex = 0
        Me.gbTipoGioco.TabStop = False
        Me.gbTipoGioco.Text = "Modalità gioco"
        '
        'rbComp
        '
        Me.rbComp.AutoSize = True
        Me.rbComp.Location = New System.Drawing.Point(275, 27)
        Me.rbComp.Name = "rbComp"
        Me.rbComp.Size = New System.Drawing.Size(90, 21)
        Me.rbComp.TabIndex = 2
        Me.rbComp.Text = "Computer"
        Me.rbComp.UseVisualStyleBackColor = True
        '
        'rbG2
        '
        Me.rbG2.AutoSize = True
        Me.rbG2.Location = New System.Drawing.Point(157, 28)
        Me.rbG2.Name = "rbG2"
        Me.rbG2.Size = New System.Drawing.Size(98, 21)
        Me.rbG2.TabIndex = 1
        Me.rbG2.Text = "2 Giocatori"
        Me.rbG2.UseVisualStyleBackColor = True
        '
        'rbG1
        '
        Me.rbG1.AutoSize = True
        Me.rbG1.Location = New System.Drawing.Point(21, 28)
        Me.rbG1.Name = "rbG1"
        Me.rbG1.Size = New System.Drawing.Size(103, 21)
        Me.rbG1.TabIndex = 0
        Me.rbG1.Text = "1 Giocatore"
        Me.rbG1.UseVisualStyleBackColor = True
        '
        'sbTable
        '
        Me.sbTable.Location = New System.Drawing.Point(33, 318)
        Me.sbTable.Name = "sbTable"
        Me.sbTable.Size = New System.Drawing.Size(364, 35)
        Me.sbTable.TabIndex = 2
        Me.sbTable.Value = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 299)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Pizze rimaste sul tavolo : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 367)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Pizze mangiate G1 : "
        '
        'sbG1
        '
        Me.sbG1.Location = New System.Drawing.Point(34, 385)
        Me.sbG1.Name = "sbG1"
        Me.sbG1.Size = New System.Drawing.Size(364, 35)
        Me.sbG1.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(32, 430)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(139, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Pizze mangiate G2 : "
        '
        'sbG2
        '
        Me.sbG2.Location = New System.Drawing.Point(33, 447)
        Me.sbG2.Name = "sbG2"
        Me.sbG2.Size = New System.Drawing.Size(364, 35)
        Me.sbG2.TabIndex = 6
        '
        'clbG1
        '
        Me.clbG1.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.clbG1.Enabled = False
        Me.clbG1.FormattingEnabled = True
        Me.clbG1.Items.AddRange(New Object() {"1", "2", "3"})
        Me.clbG1.Location = New System.Drawing.Point(34, 148)
        Me.clbG1.Name = "clbG1"
        Me.clbG1.Size = New System.Drawing.Size(87, 55)
        Me.clbG1.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 129)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Scelta pizze G1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 17)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Scelta pizze G2"
        '
        'clbG2
        '
        Me.clbG2.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.clbG2.Enabled = False
        Me.clbG2.FormattingEnabled = True
        Me.clbG2.Items.AddRange(New Object() {"1", "2", "3"})
        Me.clbG2.Location = New System.Drawing.Point(34, 227)
        Me.clbG2.Name = "clbG2"
        Me.clbG2.Size = New System.Drawing.Size(87, 55)
        Me.clbG2.TabIndex = 10
        '
        'lbHistory
        '
        Me.lbHistory.FormattingEnabled = True
        Me.lbHistory.ItemHeight = 16
        Me.lbHistory.Location = New System.Drawing.Point(146, 149)
        Me.lbHistory.Name = "lbHistory"
        Me.lbHistory.Size = New System.Drawing.Size(251, 132)
        Me.lbHistory.TabIndex = 12
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(247, 129)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Storia"
        '
        'udPizze
        '
        Me.udPizze.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.udPizze.Location = New System.Drawing.Point(146, 91)
        Me.udPizze.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.udPizze.Minimum = New Decimal(New Integer() {5, 0, 0, 0})
        Me.udPizze.Name = "udPizze"
        Me.udPizze.Size = New System.Drawing.Size(48, 22)
        Me.udPizze.TabIndex = 14
        Me.udPizze.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(34, 94)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 17)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Pizze totali"
        '
        'lbTable
        '
        Me.lbTable.AutoSize = True
        Me.lbTable.Location = New System.Drawing.Point(194, 299)
        Me.lbTable.Name = "lbTable"
        Me.lbTable.Size = New System.Drawing.Size(16, 17)
        Me.lbTable.TabIndex = 16
        Me.lbTable.Text = "5"
        '
        'lblWinner
        '
        Me.lblWinner.AutoSize = True
        Me.lblWinner.Location = New System.Drawing.Point(32, 499)
        Me.lblWinner.Name = "lblWinner"
        Me.lblWinner.Size = New System.Drawing.Size(71, 17)
        Me.lblWinner.TabIndex = 17
        Me.lblWinner.Text = "Vincitore: "
        '
        'lblPizzeG1
        '
        Me.lblPizzeG1.AutoSize = True
        Me.lblPizzeG1.Location = New System.Drawing.Point(168, 367)
        Me.lblPizzeG1.Name = "lblPizzeG1"
        Me.lblPizzeG1.Size = New System.Drawing.Size(16, 17)
        Me.lblPizzeG1.TabIndex = 19
        Me.lblPizzeG1.Text = "0"
        '
        'lblPizzeG2
        '
        Me.lblPizzeG2.AutoSize = True
        Me.lblPizzeG2.Location = New System.Drawing.Point(167, 430)
        Me.lblPizzeG2.Name = "lblPizzeG2"
        Me.lblPizzeG2.Size = New System.Drawing.Size(16, 17)
        Me.lblPizzeG2.TabIndex = 20
        Me.lblPizzeG2.Text = "0"
        '
        'btnStartStop
        '
        Me.btnStartStop.BackColor = System.Drawing.Color.LimeGreen
        Me.btnStartStop.ForeColor = System.Drawing.Color.White
        Me.btnStartStop.Location = New System.Drawing.Point(323, 82)
        Me.btnStartStop.Name = "btnStartStop"
        Me.btnStartStop.Size = New System.Drawing.Size(75, 36)
        Me.btnStartStop.TabIndex = 21
        Me.btnStartStop.Text = "Start"
        Me.btnStartStop.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 526)
        Me.Controls.Add(Me.btnStartStop)
        Me.Controls.Add(Me.lblPizzeG2)
        Me.Controls.Add(Me.lblPizzeG1)
        Me.Controls.Add(Me.lblWinner)
        Me.Controls.Add(Me.lbTable)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.udPizze)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lbHistory)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.clbG2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.clbG1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.sbG2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.sbG1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.sbTable)
        Me.Controls.Add(Me.gbTipoGioco)
        Me.Name = "Form1"
        Me.Text = "Pizza Game"
        Me.gbTipoGioco.ResumeLayout(False)
        Me.gbTipoGioco.PerformLayout()
        CType(Me.udPizze, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents gbTipoGioco As GroupBox
    Friend WithEvents rbG2 As RadioButton
    Friend WithEvents rbG1 As RadioButton
    Friend WithEvents sbTable As ProgressBar
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents sbG1 As ProgressBar
    Friend WithEvents Label3 As Label
    Friend WithEvents sbG2 As ProgressBar
    Friend WithEvents clbG1 As CheckedListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents clbG2 As CheckedListBox
    Friend WithEvents lbHistory As ListBox
    Friend WithEvents Label6 As Label
    Friend WithEvents udPizze As NumericUpDown
    Friend WithEvents Label7 As Label
    Friend WithEvents rbComp As RadioButton
    Friend WithEvents lbTable As Label
    Friend WithEvents lblWinner As Label
    Friend WithEvents lblPizzeG1 As Label
    Friend WithEvents lblPizzeG2 As Label
    Friend WithEvents btnStartStop As Button
End Class
