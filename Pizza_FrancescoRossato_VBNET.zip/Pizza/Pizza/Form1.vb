﻿
Public Class Form1

    Public objTavoloGioco As tavoloGioco
    Public objGiocatore1, objGiocatore2 As giocatore

    Private Sub udPizze_ValueChanged(sender As Object, e As EventArgs) Handles udPizze.ValueChanged
        ' Imposta in numero totale di pizze sul tavolo 
        sbTable.Maximum = udPizze.Value
        sbTable.Value = udPizze.Value
        lbTable.Text = udPizze.Value
        sbG1.Maximum = udPizze.Value
        sbG2.Maximum = udPizze.Value
    End Sub

    Private Sub clbG1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles clbG1.SelectedIndexChanged

        If clbG1.SelectedIndex = -1 Then Exit Sub

        ' Giocatore 1 mangia 1,2 o 3 pizze
        ' Verifica che la scelta non sia già stata fatta da altro giocatore
        ' Verifica che le pizze rimaste siano sufficienti altrimenti il giocatore deve fare un'altra scelta
        If Not (objGiocatore1.mangia(clbG1.SelectedIndex + 1, objTavoloGioco)) Then
            MsgBox("Scelta non valida: pizze rimaste insufficienti o scelta già fatta da altro giocatore", MsgBoxStyle.Critical)
            clbG1.ClearSelected()
            Exit Sub
        End If

        clbG1.ClearSelected()

        'Aggiorna i contatori
        lbHistory.Items.Add("G1 Mangiate " & objTavoloGioco.pizzeMangiateUltimoTurno & " Rimaste " & objTavoloGioco.pizzeRimaste)

        lblPizzeG1.Text = objGiocatore1.pizzeMangiate
        sbG1.Value = objGiocatore1.pizzeMangiate
        sbTable.Value = objTavoloGioco.pizzeRimaste
        lbTable.Text = objTavoloGioco.pizzeRimaste

        'Criterio di arresto
        If objTavoloGioco.pizzeRimaste < 3 Then
            btnStartStop_Click(Me, Nothing)
            Exit Sub
        End If

        ' Verifica se secondo giocatore è il computer
        If rbG1.Checked Then
            giocaComputer(objGiocatore2)

            'Aggiorna i contatori
            lbHistory.Items.Add("G2 Mangiate " & objTavoloGioco.pizzeMangiateUltimoTurno & " Rimaste " & objTavoloGioco.pizzeRimaste)

            lblPizzeG2.Text = objGiocatore2.pizzeMangiate
            sbG2.Value = objGiocatore2.pizzeMangiate
            sbTable.Value = objTavoloGioco.pizzeRimaste
            lbTable.Text = objTavoloGioco.pizzeRimaste

            'Criterio di arresto
            If objTavoloGioco.pizzeRimaste < 3 Then btnStartStop_Click(Me, Nothing)
        End If

        'Passa il controllo al secondo giocatore
        clbG1.Enabled = Not (rbG2.Checked)
        clbG2.Enabled = rbG2.Checked

    End Sub

    Private Sub clbG2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles clbG2.SelectedIndexChanged

        If clbG1.SelectedIndex = -1 Then Exit Sub

        ' Giocatore 2 mangia 1,2 o 3 pizze
        ' Verifica che la scelta non sia già stata fatta da altro giocatore
        ' Verifica che le pizze rimaste siano sufficienti altrimenti il giocatore deve fare un'altra scelta
        If Not (objGiocatore2.mangia(clbG2.SelectedIndex + 1, objTavoloGioco)) Then
            MsgBox("Scelta non valida: pizze rimaste insufficienti o scelta già fatta da altro giocatore", MsgBoxStyle.Critical)
            clbG1.ClearSelected()
            Exit Sub
        End If

        clbG1.ClearSelected()

        'Aggiorna i contatori
        lbHistory.Items.Add("G2 Mangiate " & objTavoloGioco.pizzeMangiateUltimoTurno & " Rimaste " & objTavoloGioco.pizzeRimaste)

        lblPizzeG2.Text = objGiocatore2.pizzeMangiate
        sbG2.Value = objGiocatore2.pizzeMangiate
        sbTable.Value = objTavoloGioco.pizzeRimaste
        lbTable.Text = objTavoloGioco.pizzeRimaste

        'Criterio di arresto
        If objTavoloGioco.pizzeRimaste < 3 Then
            btnStartStop_Click(Me, Nothing)
            Exit Sub
        End If

        'Passa il controllo al primo giocatore
        clbG2.Enabled = False
        clbG1.Enabled = True
    End Sub

    Private Sub btnStartStop_Click(sender As Object, e As EventArgs) Handles btnStartStop.Click
        ' L'utente inizia il gioco
        If IsNothing(objTavoloGioco) Then
            'Instanzio la classe tavoloGioco e le classi giocatore1 e giocatore2
            objTavoloGioco = New tavoloGioco
            objTavoloGioco.pizzeRimaste = udPizze.Value
            objGiocatore1 = New giocatore
            objGiocatore2 = New giocatore

            'Passa il controllo al primo giocatore
            clbG2.Enabled = False
            clbG1.Enabled = Not (rbComp.Checked)

            'Azzero i contatori
            lblPizzeG1.Text = "0"
            sbG1.Value = 0
            lblPizzeG2.Text = "0"
            sbG2.Value = 0
            sbTable.Value = objTavoloGioco.pizzeRimaste
            lbTable.Text = objTavoloGioco.pizzeRimaste
            lbHistory.Items.Clear()
            btnStartStop.Text = "Stop"
            lblWinner.Text = "The winner is..."

            'il pulsante cambia colore
            gbTipoGioco.Enabled = False
            udPizze.Enabled = False
            btnStartStop.BackColor = Color.Red
            gbTipoGioco.Enabled = False

            ' Gioco computer contro computer
            If Not (rbG2.Checked) And Not (rbG1.Checked) Then
                Do Until objTavoloGioco.pizzeRimaste < 3
                    giocaComputer(objGiocatore1)
                    lbHistory.Items.Add("G1 Mangiate " & objTavoloGioco.pizzeMangiateUltimoTurno & " Rimaste " & objTavoloGioco.pizzeRimaste)
                    lblPizzeG1.Text = objGiocatore1.pizzeMangiate
                    sbG1.Value = objGiocatore1.pizzeMangiate
                    sbTable.Value = objTavoloGioco.pizzeRimaste
                    lbTable.Text = objTavoloGioco.pizzeRimaste

                    giocaComputer(objGiocatore2)
                    lbHistory.Items.Add("G2 Mangiate " & objTavoloGioco.pizzeMangiateUltimoTurno & " Rimaste " & objTavoloGioco.pizzeRimaste)
                    lblPizzeG2.Text = objGiocatore2.pizzeMangiate
                    sbG2.Value = objGiocatore2.pizzeMangiate
                    sbTable.Value = objTavoloGioco.pizzeRimaste
                    lbTable.Text = objTavoloGioco.pizzeRimaste
                Loop
                btnStartStop_Click(Me, Nothing)
            End If
        Else
            'L'utente ferma il gioco
            'Le istanze delle classi vengono distrutte
            btnStartStop.Text = "Start"
            btnStartStop.BackColor = Color.Green
            gbTipoGioco.Enabled = True
            udPizze.Enabled = True
            gbTipoGioco.Enabled = True
            clbG1.Enabled = False
            clbG2.Enabled = False
            clbG2.BackColor = Color.Gray
            clbG1.BackColor = Color.Gray

            'Mostra il vincitore
            lblWinner.Text = "Vince " & objTavoloGioco.verificaVincita & " !!!!"

            objTavoloGioco = Nothing
            objGiocatore1 = Nothing
            objGiocatore2 = Nothing
        End If

    End Sub

    Sub giocaComputer(ByRef objGiocatore As giocatore)
        Dim pizzeMangiate As Integer = objTavoloGioco.pizzeMangiateUltimoTurno
        'Il computer fa una scelta a caso tra 1 e 3 pizze da mangiare
        Randomize()
        Dim upperbound = 2
        Dim lowerbound = 1
        Do Until objGiocatore.mangia(pizzeMangiate, objTavoloGioco)
            pizzeMangiate = CInt(Math.Floor((upperbound - lowerbound + 1) * Rnd())) + lowerbound
        Loop
    End Sub

End Class
